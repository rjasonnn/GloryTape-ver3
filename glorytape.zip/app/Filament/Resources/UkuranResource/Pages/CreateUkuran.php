<?php

namespace App\Filament\Resources\UkuranResource\Pages;

use App\Filament\Resources\UkuranResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateUkuran extends CreateRecord
{
    protected static string $resource = UkuranResource::class;
}
