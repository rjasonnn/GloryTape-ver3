<div <?php echo e($attributes->class(['flex gap-x-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH E:\Web Project\reyhan\reyhan3\GloryTape\resources\views/vendor/filament-forms/components/rich-editor/toolbar/group.blade.php ENDPATH**/ ?>